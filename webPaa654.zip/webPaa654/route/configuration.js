module.exports = function(app, db){
            
	app.get('/tablaclientes', function(req,res){

        res.send('Tabla Clientes');
	});

	app.get('/preciocombustibles', function(req,res){

		res.render('preciocombustibles',{

			title:'Title',
			name: 'Precio Combustibles'            
		});
	});

	app.get('/tasadeldolar', function(req,res){
        
        res.render('tasadeldolar',{

			title:'Title',
			name: 'Tasa del Dolar'            
		});
	});

	app.get('/tarifaxrutas', function(req,res){
        
        res.render('tarifaxrutas',{

			title:'Title',
			name: 'Tarifa por Rutas'            
		});
	});

	app.get('/usuarios', function(req,res){
        
        res.send('Tabla Usuarios');
	});

}